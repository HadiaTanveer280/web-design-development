<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Student Dashboard</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: linear-gradient(135deg, #a18cd1, #fbc2eb); /* Purple–Pink Gradient */
      margin: 0;
      padding: 0;
    }

    header {
      background: #4a148c; /* Deep Violet */
      color: white;
      padding: 25px;
      text-align: center;
      box-shadow: 0 4px 10px rgba(0,0,0,0.3);
    }

    nav {
      display: flex;
      justify-content: center;
      gap: 30px;
      margin: 40px 0;
    }

    nav a {
      background: white;
      padding: 15px 30px;
      border-radius: 10px;
      text-decoration: none;
      font-weight: bold;
      color: #4a148c;
      transition: 0.3s ease;
      box-shadow: 0 4px 10px rgba(0,0,0,0.2);
    }

    nav a:hover {
      background: #6a1b9a; /* Hover Violet */
      color: white;
      box-shadow: 0 6px 15px rgba(0,0,0,0.3);
    }
  </style>
</head>
<body>
  <header>
    <h1>🎓 Student Management System</h1>
    <p>Dashboard</p>
  </header>
  <nav>
    <a href="add_student.php">➕ Add Student</a>
    <a href="view_students.php">📋 View Students</a>
  </nav>
</body>
</html>
