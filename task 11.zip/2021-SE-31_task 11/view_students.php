<?php
$conn = new mysqli("localhost", "root", "", "student_db");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$result = $conn->query("SELECT * FROM students");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>View Students</title>
  <style>
    body { font-family: Arial, sans-serif; background: #eef2f3; padding: 30px; }
    table {
      width: 80%; margin: auto; border-collapse: collapse;
      background: white; box-shadow: 0px 4px 12px rgba(0,0,0,0.2);
    }
    th, td {
      border: 1px solid #ddd; padding: 12px; text-align: center;
    }
    th { background: #1a1a2e; color: white; }
    tr:nth-child(even) { background: #f2f2f2; }
    h2 { text-align: center; margin-bottom: 20px; }
  </style>
</head>
<body>
  <h2>Student Records</h2>
  <table>
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Email</th>
      <th>Course</th>
      <th>Added On</th>
    </tr>
    <?php while($row = $result->fetch_assoc()) { ?>
      <tr>
        <td><?= $row["id"] ?></td>
        <td><?= $row["name"] ?></td>
        <td><?= $row["email"] ?></td>
        <td><?= $row["course"] ?></td>
        <td><?= $row["created_at"] ?></td>
      </tr>
    <?php } ?>
  </table>
</body>
</html>
<?php $conn->close(); ?>
