<?php
$success = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $conn = new mysqli("localhost", "root", "", "student_db");
  if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

  $name = $_POST["name"];
  $email = $_POST["email"];
  $course = $_POST["course"];

  $sql = "INSERT INTO students (name, email, course) VALUES ('$name', '$email', '$course')";
  if ($conn->query($sql) === TRUE) {
    $success = "✅ Student added successfully!";
  } else {
    $success = "❌ Error: " . $conn->error;
  }
  $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add Student</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f0f2f5; }
    .container {
      width: 400px; margin: 50px auto; padding: 20px;
      background: white; border-radius: 10px;
      box-shadow: 0px 4px 10px rgba(0,0,0,0.2);
    }
    h2 { text-align: center; color: #333; }
    input, select {
      width: 100%; padding: 10px; margin: 10px 0;
      border: 1px solid #ccc; border-radius: 6px;
    }
    button {
      width: 100%; padding: 12px;
      background: #1a1a2e; color: white;
      border: none; border-radius: 6px;
      font-size: 16px; cursor: pointer;
    }
    button:hover { background: #4facfe; }
    .msg { text-align: center; color: green; font-weight: bold; }
  </style>
</head>
<body>
  <div class="container">
    <h2>Add New Student</h2>
    <form method="POST">
      <input type="text" name="name" placeholder="Enter Name" required>
      <input type="email" name="email" placeholder="Enter Email" required>
      <select name="course" required>
        <option value="">-- Select Course --</option>
        <option value="Computer Science">Computer Science</option>
        <option value="Software Engineering">Software Engineering</option>
        <option value="IT">Information Technology</option>
      </select>
      <button type="submit">Add Student</button>
    </form>
    <p class="msg"><?= $success ?></p>
  </div>
</body>
</html>
